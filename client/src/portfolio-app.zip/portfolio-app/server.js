require('dotenv').config();
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { Pool } = require('pg');

const app = express();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : false,
});

app.set('trust proxy', 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ['https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'"],
    },
  },
}));
app.use(express.json({ limit: '10kb' }));
app.use(express.static(path.join(__dirname, 'client', 'dist')));

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 5, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many messages. Please try again later.' } });

const clean = (v, max) => (typeof v === 'string' ? v.trim().slice(0, max) : '');

app.post('/api/contact', limiter, async (req, res) => {
  const { website } = req.body || {};
  if (website) return res.json({ ok: true }); // honeypot: silently drop bots

  const name = clean(req.body?.name, 100);
  const email = clean(req.body?.email, 150);
  const phone = clean(req.body?.phone, 30);
  const message = clean(req.body?.message, 3000);

  if (!name || !email || !message) return res.status(400).json({ error: 'Name, email and message are required.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Please enter a valid email.' });
  if (phone && !/^[0-9+()\-.\s]{5,30}$/.test(phone)) return res.status(400).json({ error: 'Please enter a valid phone number.' });

  try {
    await pool.query(
      'INSERT INTO contact_messages (name, email, phone, message, ip) VALUES ($1,$2,$3,$4,$5)',
      [name, email, phone || null, message, req.ip]
    );
    res.status(201).json({ ok: true });
  } catch (err) {
    console.error('DB error:', err.message);
    res.status(500).json({ error: 'Server error. Please try again later.' });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Portfolio running on http://localhost:${port}`));
