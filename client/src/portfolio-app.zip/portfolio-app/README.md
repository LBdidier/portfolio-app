# Didier Luboya portfolio (React + Vite, Node.js, PostgreSQL)

```
client/   React app (Vite)  ->  src/App.jsx, src/data.js, src/styles.css
server.js Express API (POST /api/contact) + serves client/dist
schema.sql PostgreSQL table for contact messages
```

## Setup
1. `npm install`
2. `createdb portfolio`, then `cp .env.example .env` and set `DATABASE_URL`
3. `npm run db:init`
4. Put your transparent PNG at `client/public/photo.png`
5. Set your LinkedIn / Instagram URLs in `client/src/data.js` (`LINKS`)

## Develop (two terminals)
- `npm start` (API on :3000)
- `npm run dev:client` (React on :5173, proxies /api to :3000)

## Production
`npm run build` then `npm start`, open http://localhost:3000

## Read messages
`psql "$DATABASE_URL" -c "SELECT id,name,email,phone,message,created_at FROM contact_messages ORDER BY created_at DESC;"`

Deploy to any Node host (e.g. Azure App Service). Set `DATABASE_URL`, and `PGSSL=true` for managed Postgres.
